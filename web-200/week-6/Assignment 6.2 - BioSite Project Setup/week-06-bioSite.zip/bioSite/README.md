# BioSite
This bio site focus on building a fluid website thats reuseable.